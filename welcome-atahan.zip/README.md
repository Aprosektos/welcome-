# Welcome-Bot Altyapısı
Discord sunucularınızda kullanmanız için kodlanmış bir " Sesli Karşılama Botu " projesi.

# Nasıl Kullanılır?
Öncelikle settings.json kısmını doldurursanız bot çalışmaya başlayacaktır.

iyi kodlamalar <3